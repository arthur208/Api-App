package br.edu.unicesumar.example;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class ExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
