# Api App Torneios 

Para primeira utilizacao instale os seguintes pacotes
java runtime versao 17
e as extensoes seguintes no seu vscode
Spring Boot Dashboard
Lombok Annotations Support for VS Code
Maven for Java
Project Manager for Java
Spring Boot Extension Pack
Spring Boot Tools
Spring Initializr Java Support
Test Runner for Java
Language Support for Java(TM) by Red Hat
Extension Pack for Java
Debugger for Java

instale o postgess e crie um banco de dados chamado Api-App
